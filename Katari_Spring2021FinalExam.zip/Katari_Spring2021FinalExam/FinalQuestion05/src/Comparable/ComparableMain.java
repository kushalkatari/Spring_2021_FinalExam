/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comparable;

/**
 *
 * @author Kushal Satya Durgaji Katari
 */

public class ComparableMain 
{

    /**
     * @param args the command line arguments
     */
    
     /** Main method */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Answer for question 5 : Kushal Katari");
    	
	/* Created two  ComparableCircle objects */
	ComparableCircle comparableCircle1 = new ComparableCircle(30);
	ComparableCircle comparableCircle2 = new ComparableCircle(20);

	/* To Display Circles */
	System.out.println("\nCircle1:");
	System.out.println(comparableCircle1);
	System.out.println("\nCircle2:");
	System.out.println(comparableCircle2);

	/* To display the larger Circle */
	System.out.println((comparableCircle1.compareTo(comparableCircle2) == 1 
	? "\nCircle1 " : "\nCircle2 ") + "is the larger Circle");
	}
        }
    
    

