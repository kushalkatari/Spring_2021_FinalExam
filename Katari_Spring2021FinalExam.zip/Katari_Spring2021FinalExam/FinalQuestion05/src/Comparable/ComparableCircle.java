/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comparable;

/**
 *
 * @author Kushal Satya Durgaji Katari
 */

    /* ComparableCircle extends Circle */
      public class ComparableCircle extends Circle 
		implements Comparable<ComparableCircle> {

	

	/** Constructor for ComparableCircle */
	public ComparableCircle(double radius) {
		super(radius);
	}

	
        /*  compareTo method */
	@Override 
	public int compareTo(ComparableCircle o) 
        {
		if (getArea() > o.getArea())
			return 1;
		else if (getArea() < o.getArea())
			return -1;
		else
			return 0;
	}

        /* toString method  */
        @Override 
	public String toString() {
		return super.toString() + "\nArea: " + getArea();
	}
}

