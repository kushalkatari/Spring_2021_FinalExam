/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comparable;

/**
 *
 * @author Kushal Satya Durgaji Katari
 */

    public class Circle
	 {
	private double radius;

	public Circle() 
        {
	}
        
       /* constructors for Circle */ 
        public Circle(double radius)
        {
		this.radius = radius;
	}

	/** gets radius */
	public double getRadius() 
        {
		return radius;
	}

	/** Sets radius */
	public void setRadius(double radius) 
        {
		this.radius = radius;
	}

	/** gets area */
	public double getArea()
        {
		return radius * radius * Math.PI;
	}

	/** gets diameter */
	public double getDiameter()
        {
		return 2 * radius;
	}

	/** gets perimeter */
	public double getPerimeter() 
        {
		return 2 * radius * Math.PI;
	}
        
        /**  toString method  */
	@Override 
	public String toString()
        {
		return "Radius: " + radius;
	}
        }
