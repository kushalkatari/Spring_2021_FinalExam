/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author Kushal satya durgaji Katari
 */
public class EmployeeMain {

    /**
     * @param args the command line arguments
     */
    /* Main method */
         public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Answer for question 12 : Kushal Katari");
        
        /* ArrayList for employee list to display details of employee */
        ArrayList<Employee> employeeList = new ArrayList<Employee>();
        employeeList.add(new Employee("111", "Sachin", 8000.0));
	employeeList.add(new Employee("555", "Kohli", 5600.0));
	employeeList.add(new Employee("333", "Williamson", 59000.0));
	employeeList.add(new Employee("222", "Bairstow", 3400.0));
	employeeList.add(new Employee("444", "David warner", 9000.0));
	System.out.println("Employees original list: ");
	
        for(Employee emp : employeeList)
	{
	System.out.println(emp);
	}
	System.out.println();
		
	/* To display employee list sorting by the id */
        Collections.sort(employeeList);
	System.out.println("Employees List sorting by ID:");
	for(Employee emp : employeeList)
	{
	System.out.println(emp);
	}
	System.out.println();
			
	/* To display employee list sorting by the salary */
        Collections.sort(employeeList, new Comparator<Employee>()
      	{
        @Override
	public int compare(Employee emp1, Employee emp2)
	{
	if(emp1.getEmpSalary() < emp2.getEmpSalary())
	return -1;
	else if (emp1.getEmpSalary() == emp2.getEmpSalary())
	return 0;
	else
	return +1;					
        }
      	}
        );
        
        System.out.println("Employees List sorting by Salary:");
	for(Employee emp : employeeList)
	{
	System.out.println(emp);
	}
	System.out.println();
		
	/* To display employee list sorting by the name */
        Collections.sort(employeeList, new Comparator<Employee>()
      	{
	public int compare(Employee emp1, Employee emp2)
	{
	return (emp1.getEmpName()).compareTo(emp2.getEmpName());
        }
      	}
        );
		
        System.out.println("Employees List sorting by Name:");
	for(Employee emp : employeeList)
	{
	System.out.println(emp);
	}
	System.out.println();
	}
        }
    
    

