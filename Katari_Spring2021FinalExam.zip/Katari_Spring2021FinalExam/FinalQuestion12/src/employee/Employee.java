/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author Kushal satya durgaji Katari
 */
    /* Employee class that implements comparable - employee*/
    public class Employee implements Comparable<Employee>
    {
    private String empId;
    private String empName;
    private double empSalary;

    /**Constructors for empID,empName,empSalary
    @param empId
    @param empName
    @param empSalary
    */
    
    public Employee(String empId, String empName, double empSalary) 
    {
        this.empId= empId;
        this.empName= empName;
        this.empSalary= empSalary;
    }

    /* gets EmpID*/
    public String getEmpId() 
    {
        return empId;
    }

    /* gets EmpName*/
    public String getEmpName()
    {
        return empName;
    }

    /* gets Emp Salary*/
    public double getEmpSalary() 
    {
        return empSalary;
    }
       
    /* compareTo method */
    @Override
    public int compareTo(Employee obj) 
    {
        return empId.compareTo(obj.empId);
    }

    /* To string method */
    @Override
    public String toString() 
    {
        return empId + " " + empName + " " + empSalary;
    }
}