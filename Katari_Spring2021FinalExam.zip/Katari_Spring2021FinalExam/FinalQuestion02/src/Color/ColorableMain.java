/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Color;

/**
 *
 * @author Kushal Satya Durgaji Katari
 */

       public class ColorableMain
       {
	/** Main method */
	public static void main(String[] args) 
        {
            System.out.println("Answer for question 2 : Kushal Katari");
		// created array of five GeometricObjects 
		GeometricObject[] s = {new Square(4), new Square(6), 
		new Square(8), new Square(10), new Square(12)};

		// To display the area and howToColor method 
		// for loop method for  GeometricObject
		for (int i = 0; i < s.length; i++) 
                {
                        System.out.println("\nSquare: " + (i + 1));
		 	System.out.println("Area: " + s[i].getArea());
		 	System.out.println("How to color: " + ((Square)s[i]).howToColor());
		 } 
	}
}