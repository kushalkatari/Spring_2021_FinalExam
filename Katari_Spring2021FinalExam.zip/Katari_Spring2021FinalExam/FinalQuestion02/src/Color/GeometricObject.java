
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Color;



/**
 *
 * @author Kushal Satya Durgaji Katari
 */


public abstract class GeometricObject
{
	private String color = "white";
	private boolean filled;
	private java.util.Date dateCreated;

	/**  default geometric object */
	public GeometricObject() 
        {
		dateCreated = new java.util.Date();
	}

	/**  geometric object with color and filled value */
	public GeometricObject(String color, boolean filled)
        {
		dateCreated = new java.util.Date();
		this.color = color;
		this.filled = filled;
	}

	/** gets  color */
	public String getColor()
        {
		return color;
	}

	/** Sets  color */
	public void setColor(String color) 
        {
		this.color = color;
	}

	/** isFilled method */
	public boolean isFilled() {
		return filled;
	}

	/** Sets  filled method */
	public void setFilled(boolean filled) 
        {
		this.filled = filled;
	}

	/** gets dateCreated */
	public java.util.Date getDateCreated() 
        {
		return dateCreated;
	}

	@Override
	public String toString() {
		return "created on " + dateCreated + "\ncolor: " + color +
			" and filled: " + filled;
	}

	/** Abstract method gets Area */
	public abstract double getArea();

	/** Abstract method gets Perimeter */
	public abstract double getPerimeter();
          }