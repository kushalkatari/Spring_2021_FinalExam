/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wideningTypeCasting;

/**
 *
 * @author Kushal Satya Durgaji Katari
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
    // create int type variable
    int num = 10;
    System.out.println("Answer for question 3 : Kushal Katari");
    System.out.println("The integer value: " + num);
    // convert into double type
    double data = num;
    System.out.println("The double value: " + data);
  }
}

    
    
