/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

/**
 * @author Kushal Satya Durgaji Katari
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here      
        // creating methods for Car.
        System.out.println("Answer for question 1 : Kushal Katari");
        Car car = new Car();
        car.Gear(4);
        car.speed(60);
        car.Brakes(20);          
        System.out.println("Car position :");
        car.printStates();  
        // creating methods for bike.
        Bike bike = new Bike();
        bike.Gear(8);
        bike.speed(120);
        bike.Brakes(30);     
        System.out.println("Bike position :");
        bike.printStates();
        }
        }
    
    

