/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package EqualsAndHash;

import java.io.*;

/**
 *
 * @author Kushal Satya Durgaji Katari
 */

  
    /* Equals method is used to simply verify the equality of two objects.
    It’s default implementation simply check the object references of two objects to verify their equality.
    By default, two objects are equal if and only if they are stored in the same memory address.
    The java equals() is a method of lang.Object class, and it is used to compare two objects.
    To compare two objects that whether they are the same, it compares the values of both the object's attributes.*/
  
   public class Equals 
   {     
    public String name;
    public int id;
          
    Equals(String name, int id) 
    {       
        this.name = name;
        this.id = id;
    }
      
    @Override
    public boolean equals(Object obj)
    { 
        
    // checking if both the object references are referring to the same object.
    if(this == obj)
            return true;
          
        /* It is checking if the argument is of the  type Equals by comparing the classes */      
        
        if(obj == null || obj.getClass()!= this.getClass())
            return false;
          
       /* A hashcode is an integer value associated with every object in Java, facilitating the hashing in hash tables.
        To get this hashcode value for an object, we can use the hashcode() method in Java.
        It is the means hashcode() method that returns the integer hashcode value of the given object.
        Since this method is defined in the Object class, hence it is inherited by user-defined classes also.
        The hashcode() method returns the same hash value when called on two objects, 
        which are equal according to the equals() method. And if the objects are unequal, it usually returns different hash values. */
        
        
        
        
        Equals hash = (Equals) obj;
          
        /* comparing the state of argument with the state of 'this' Object. */
        
        return (hash.name == this.name && hash.id == this.id);
    }
      
    @Override
    public int hashCode()
    {
          
       
        return this.id;
    }
      
}